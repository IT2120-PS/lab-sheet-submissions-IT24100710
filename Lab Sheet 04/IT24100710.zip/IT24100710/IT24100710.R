setwd("C://Users//IT24100710//Documents//Lab 04-20250821")

branch_data <- read.table("Exercise.txt",header = TRUE, sep = ",")

str(branch_data)

fix(branch_data)

boxplot(branch_data$Sales_X1,main="Box plot for Branch Sales", ylab = "Sales",outline=TRUE,horizontal=TRUE)

summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)


find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  outliers <- x[x < lower_bound | x > upper_bound]
  
  if(length(outliers) == 0) {
    return("No outliers detected")
  } else {
    return(sort(outliers))
  }
}

years_outliers <- find_outliers(branch_data$Years)
print(paste(paste(years_outliers, collapse=", ")))

